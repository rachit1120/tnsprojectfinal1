package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.College;
import com.example.service.CollegeService;

@RestController
public class CollegeController {
	
	@Autowired
	private CollegeService service; 
	
	@PostMapping("/college_Table")
	public College saveCollege(@RequestBody College college) {
		return service.saveCollege(college);
	}
	
	@GetMapping("/college_Table")
	public List<College> getCollegeList() {
		return service.getCollegeList();
	}
	
	@GetMapping("/college_Table/{id}")
	public College getCollegeById(@PathVariable("id") Long id) {
		return service.getCollegeById(id);
	}
	
	@DeleteMapping("/college_Table/{id}")
	public String removeCollegeById(@PathVariable("id") Long id) {
		service.removeCollegeById(id);
		return "Record removed / deleted Successfully!";
	}
	
	
	@PutMapping("/college_Table/{id}")
	public College updateCollege(@PathVariable("id") Long id,@RequestBody College college) {
		return service.updateCollege(id, college);
		
	}
}
