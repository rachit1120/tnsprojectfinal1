package com.example.service;

import java.util.List;

import com.example.entity.College;

public interface CollegeService {

	College saveCollege(College college);

	List<College> getCollegeList();

	College getCollegeById(Long id);

	void removeCollegeById(Long id);

	College updateCollege(Long id, College college);

}
