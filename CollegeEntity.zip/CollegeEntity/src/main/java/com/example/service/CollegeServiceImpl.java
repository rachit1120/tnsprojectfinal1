package com.example.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.College;
import com.example.repository.CollegeRepository;

@Service
public class CollegeServiceImpl implements CollegeService{
	
	@Autowired
	private CollegeRepository repository;

	@Override
	public College saveCollege(College college) {
		return repository.save(college);
	}

	@Override
	public List<College> getCollegeList() {
		return repository.findAll();
	}

	@Override
	public College getCollegeById(Long id) {
		return repository.findById(id).get();
	}

	@Override
	public void removeCollegeById(Long id) {
		repository.deleteById(id);		
	}

	@Override
	public College updateCollege(Long id, College collegeName) {
		College college = repository.findById(id).get();
		
		if(Objects.nonNull(collegeName.getCollegeName()) && 
				!"".equalsIgnoreCase(collegeName.getCollegeName())) {
			college.setCollegeName(collegeName.getCollegeName());
		}
		
		if(Objects.nonNull(collegeName.getLocation()) && 
				!"".equalsIgnoreCase(collegeName.getLocation())) {
			college.setLocation(collegeName.getLocation());
		}
		
		return repository.save(college);
	}
}
